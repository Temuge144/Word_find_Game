import 'package:flutter/material.dart';
import 'package:word_find_app/home_screen.dart';


void main() {
  runApp(MaterialApp(
    home: HomeScreen(),
  ));
}