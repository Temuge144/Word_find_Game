package com.example.lesson_day_12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
