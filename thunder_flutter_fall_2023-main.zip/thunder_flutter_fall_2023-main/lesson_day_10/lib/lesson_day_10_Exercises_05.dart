abstract class Person {
  String name;
  int age;

  Person(this.name, this.age);

  void details();
}

class Student extends Person {
  Student(super.name, super.age);

  @override
  void details() {
    print('Name: $name, Age: $age, School: ABC School');
  }
}

class Teacher extends Person {
  Teacher(super.name, super.age);

  @override
  void details() {
    print('Name: $name, Age: $age, Subject: Mathematics');
  }
}

void main(){
  Student student = Student('john', 20);
  student.details();
  Teacher teacher = Teacher('Jane', 30);
  teacher.details();
}