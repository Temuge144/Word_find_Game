abstract class Account {
  int accountNumber;
  double blance;

  Account(this.accountNumber, this.blance);

  double deposit(double amount);
  double withdraw(double amount);
  String typeOfAccount();
}

class SavingAccount extends Account {
  SavingAccount(super.accountNumber, super.blance);

  @override
  double deposit(double amount) {
    blance = blance + amount;
    return blance;
  }

  @override
  double withdraw(double amount){
    if (blance - amount < 0){
      print('Insufficient Balance');
    }
    blance = blance - amount;
    return blance;
  }

  @override
  String typeOfAccount() {
    return 'Savings Account';
  }
}

class CurrentAccount extends Account {
  CurrentAccount(super.accountNumber, super.blance);

  @override
  double deposit(double amount) {
    blance = blance - amount;
    return blance;
  }

  @override
  double withdraw(double amount){
    if (blance - amount < 0){
      print('Insufficient Balance');
    }
    blance = blance - amount;
    return blance;
  }

  @override
  String typeOfAccount() {
    return 'Current Account';
  }
}

void main(){
  SavingAccount savingAccount = SavingAccount(123456789, 1000.0);
  print('Seving Account Balance: ${savingAccount.blance}');
  print('Seving Account Balance: ${savingAccount.deposit(500)}');
  print('Insufficient funds');
  print('Seving Account Balance: ${savingAccount.blance}');
  print('Seving Account Balance: ${savingAccount.withdraw(500)}');
  print('Seving Account type: ${savingAccount.typeOfAccount()}');
  CurrentAccount currentAccount = CurrentAccount(123456789, 1000.0);
  print('Current Account Balance: ${savingAccount.blance}');
  print('Current Account Balance: ${savingAccount.deposit(500)}');
  print('Insufficient funds');
  print('Current Account Balance: ${savingAccount.blance}');
  print('Current Account Balance: ${savingAccount.withdraw(1000)}');
  print('Current Account type: ${currentAccount.typeOfAccount()}');
}