abstract class Vehicle {
  double speed;
  double fuel;

  Vehicle(this.speed, this.fuel);

  void accelerate();
  void brake();
  void fuelEfficiency();
}

class Car extends Vehicle {
  Car(super.speed, super.fuel);

  @override
  void accelerate() {
    speed = speed + 10;
    fuel = fuel - 5;
  }

  @override
  void brake(){
    speed = speed - 10;
    fuel = fuel - 5;
  }

  @override
  void fuelEfficiency(){
   print('Fuel efficiency: ${speed / fuel}');
  }
}

class Bike extends Vehicle {
  Bike(super.speed, super.fuel);

  @override
  void accelerate() {
    speed = speed + 5;
    fuel = fuel - 2;
  }

  @override
  void brake(){
    speed = speed - 5;
    fuel = fuel - 2;
  }

  @override
  void fuelEfficiency(){
    print('Fuel efficiency: ${speed / fuel}');
  }
}

class Bus extends Vehicle {
  Bus(super.speed, super.fuel);

  @override
  void accelerate() {
    speed = speed + 2;
    fuel = fuel - 10;
  }

  @override
  void brake(){
    speed = speed - 2;
    fuel = fuel - 10;
  }

  @override
  void fuelEfficiency(){
    print('Fuel efficiency: ${speed / fuel}');
  }
}

void main(){
  Car car = Car(100, 100);
  print('Car is accelating.');
  car.accelerate();
  print('Car is speed: ${car.speed}');
  print('Car is braking');
  car.brake();
  print('Car is speed: ${car.speed}');
  car.fuelEfficiency();

  Bike bike = Bike(50, 50);
  print('Bike is accelating.');
  bike.accelerate();
  print('Bike is speed: ${bike.speed}');
  print('Bike is braking');
  bike.brake();
  print('Bike is speed: ${bike.speed}');
  bike.fuelEfficiency();

  Bus bus = Bus(20, 20);
  print('Bus is accelating.');
  bus.accelerate();
  print('Bus is speed: ${bus.speed}');
  print('Bus is braking');
  bus.brake();
  print('Bus is speed: ${bus.speed}');
  bus.fuelEfficiency();
}