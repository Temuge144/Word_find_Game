abstract class FoodMenu {
  String name;
  List<String> ingredients;
  double calories = 0;

  FoodMenu(this.name, this.ingredients);

  bool isVegetarian();

}

class Pizza extends FoodMenu {
  Pizza(super.name, super.ingredients);

  @override
  bool isVegetarian() {
    if (!ingredients.contains('Meat')) {
      return true;
    } else {
      return false;
    }
  }

  double calor(){
    return calories = ingredients.length * 100;
  }
}

class Salad extends FoodMenu {
  Salad(super.name, super.ingredients);

  @override
  bool isVegetarian(){
    if(!ingredients.contains('Meat')){
      return true;
    } else {
      return false;
    }
  }

  double calor(){
    return calories = ingredients.length * 100;
  }
}

class Burder extends FoodMenu {
  Burder(super.name, super.ingredients);

  @override
  bool isVegetarian() {
    if(!ingredients.contains('Meat')){
      return true;
    } else {
      return false;
    }
  }

  double calor(){
    return calories = ingredients.length * 100;
  }
}

void main(){
  final Pizza pizza = Pizza("Pepperoni Pizza", ["Dough", "Tomato Sauce", "Cheese", "Pepperoni"]);
  print('IS ${pizza.name} vegetarian? ${pizza.isVegetarian()}');
  print(pizza.calor());

  final Salad salad = Salad("Shine nogoonii salad", ["ogortsii", "baitsaa", "luuvan"]);
  print('IS ${salad.name} vegetarian? ${salad.isVegetarian()}');
  print(salad.calor());

  final Burder burder = Burder("Burger", ["Dough", "Meat", "Cheese", "Tomato", "Baitsaa"]);
  print('IS ${burder.name} vegetarian? ${burder.isVegetarian()}');
  print(burder.calor());
}