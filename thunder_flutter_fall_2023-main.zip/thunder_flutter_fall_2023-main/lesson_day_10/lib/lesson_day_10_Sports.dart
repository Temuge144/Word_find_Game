abstract class Sportsperson {
  String name;
  int age;
  double stamina;

  Sportsperson(this.name, this.age, this.stamina);

  void train();
  void rest();
  void complete();
  void hydrate();
  String statistics();

  void introduse(){
    print("Hello, My name is $name and I am a sportsperson!");
  }
}

class Footballer extends Sportsperson{
  int goalsScored;

  Footballer(String name, int age, double stamina, this.goalsScored) : super(name, age, stamina);

  @override
  void train(){
    print("$name is training on the football field.");
  }

  @override
  void rest(){
    print("$name is resting after a football match.");
  }

  @override
  void complete(){
    print("$name is competing in a football match.");
  }

  @override
  void hydrate(){
    print("$name is drinking water during halftime.");
  }

  @override
  String statistics(){
    return "$name has scorred $goalsScored goals!";
  }
}

class Cricketeter extends Sportsperson {
  int runsScored;
  Cricketeter(String name, int age, double stamina, this.runsScored) : super(name, age, stamina);

  @override
  void train(){
    print("$name is training in the nets.");
  }

  @override
  void rest(){
    print("$name is resting after a cricket game.");
  }

  @override
  void complete(){
    print("$name is competing in a cricket match.");
  }

  @override
  void hydrate(){
    print("$name is drinking energy drink a drinks break.");
  }

  @override
  String statistics(){
    return "$name has scorred $runsScored runs!";
  }
}

void main(){
  Footballer leo = Footballer("Leo Messi", 35, 90.5, 700);
  leo.introduse();
  leo.train();
  print(leo.statistics());

  Cricketeter virat = Cricketeter("Virat Kohli", 33, 92.0, 12000);
  virat.introduse();
  virat.train();
  print(virat.statistics());
}