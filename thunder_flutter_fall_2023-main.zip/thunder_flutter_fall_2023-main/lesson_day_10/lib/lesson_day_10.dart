void main(){
  print('Lesson day 10 Abstract');
  final Horse horse = Horse('Horse', 3, 'U;laan huren');
  horse.printInfo();
  horse.shout();
  final Dog dog = Dog('Dog', 3, 'Black');
  dog.printInfo();
  dog.shout();
}

abstract class Animal {
  String name;
  int age;
  String species;

  Animal(this.name, this.age, this.species);

  void shout();

  void printInfo(){
    print('The animal name is $name, age is $age, species is $species');
  }
}

class Horse extends Animal {
  Horse(super.species, super.age, super.name);

  @override
  void shout(){
    print('Iin hoo Iin hoo');
  }
}

class Dog extends Animal {
  Dog(super.species, super.age, super.name);

  @override
  void shout(){
    print('Woof Woof!');
  }
}