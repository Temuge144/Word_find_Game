import 'dart:math';

abstract class Shape {
  double area();
  double perimeter();

}

class Circle extends Shape {

  double r;
  Circle(this.r);

  @override
  double area(){
    return pi * (r * r);
  }

  @override
  double perimeter() {
    return 2 * (pi * r);
  }
}

class Rectangle extends Shape {
  double lenght;
  double width;

  Rectangle(this.lenght, this.width);

  @override
  double area(){
    return lenght * width;
  }

  @override
  double perimeter (){
    return 2 * (lenght + width);
  }
}

class Triangle extends Shape {
  double side1;
  double side2;
  double side3;
  double base;
  double height;

  Triangle(this.side1, this.side2, this.side3, this.base, this.height);

  @override
  double area(){
    return  (height * base) / 2;
  }

  @override
  double perimeter (){
    return side1 + side2 + side3;
  }
}

void main(){
  Circle booronhii = Circle(5);
  print('Circle area : ${booronhii.area()}');
  print('Circle perimeter : ${booronhii.perimeter()}');

  Rectangle dorvoljin = Rectangle(10, 40);
  print('Rectangle area : ${dorvoljin.area()}');
  print('Rectangle perimeter : ${dorvoljin.perimeter()}');

  Triangle gurvaljin = Triangle(5, 10, 5, 10, 5);
  print('Triangle area : ${gurvaljin.area()}');
  print('Triangle perimeter : ${gurvaljin.perimeter()}');
}