void main(){
  Dog nohoi = Dog('Fido', 2);
  nohoi.pnt();
  nohoi.sound();
  nohoi.move();

  Bird shuvuu = Bird('Tweety', 1);
  shuvuu.pnt();
  shuvuu.sound();
  shuvuu.move();

  Fish zagas = Fish('Nemo', 1);
  zagas.pnt();
  zagas.sound();
  zagas.move();
}

abstract class Animal {
  String name;
  int age;

  Animal(this.name, this.age);

  void sound();

  void move();
  
  void pnt();
}

class Bird extends Animal {
  Bird(super.name, super.age);

  @override
  void sound(){
    print('Bird makes Chirp!');
  }

  @override
  void move(){
    print('Bird Flies!');
  }

  @override
  void pnt(){
    print("Bird name : $name and age : $age");
  }
}

class Dog extends Animal {
  Dog(super.name, super.age);

  @override
  void sound(){
    print('Dog makes Woof!');
  }

  @override
  void move(){
    print('Dog Runs!');
  }

  @override
  void pnt(){
    print("Dog name : $name and age : $age");
  }
}

class Fish extends Animal {
  Fish(super.name, super.age);

  @override
  void sound(){
    print('Fish makes Blub!');
  }

  @override
  void move(){
    print('Fish Swims!');
  }

  @override
  void pnt(){
    print("Fish name : $name and age : $age");
  }
}