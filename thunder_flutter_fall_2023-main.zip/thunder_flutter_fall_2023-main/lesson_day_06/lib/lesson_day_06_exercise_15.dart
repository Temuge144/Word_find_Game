void main(){
 print(celsiusToFahrenheit(0));
 print(fahrenheitToCelsius(45));
}

double celsiusToFahrenheit(double c){
  double fn = (c * 9/5) + 32;
  return fn;
}

double fahrenheitToCelsius(double f){
  double cn = (f - 32) * 5/9;
  return cn;
}