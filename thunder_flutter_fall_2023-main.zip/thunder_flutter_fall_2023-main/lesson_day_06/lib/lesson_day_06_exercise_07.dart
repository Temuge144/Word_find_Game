void main(){
  print(isOdd(20));
}

bool isOdd(int number){
  if(number % 5 == 0){
    return true;
  } else {
    return false;
  }
}