import 'dart:math';

void main(){
  print(calculateDiameter(10.5));
}

double calculateDiameter(double radius){
  double a = radius * 2;
  return a;
}