void main(){
  print(isOdd(4));
}

bool isOdd(int a){
  if(a % 2 == 0){
    return true;
  } else {
    return false;
  }
}