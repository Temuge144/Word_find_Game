import 'dart:math';

void main(){
  print(calculateCircleArea(10.5));
}

double calculateCircleArea(double radius){
  double a = pi * (radius * radius);
  return a;
}