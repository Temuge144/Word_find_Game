void main(){
  print(isLeapYear(2024));
}

bool isLeapYear(int a){
  if (a % 4 == 0 && a % 100 != 0 || a % 400 == 0){
    return true;
  } else {
    return false;
  }
}