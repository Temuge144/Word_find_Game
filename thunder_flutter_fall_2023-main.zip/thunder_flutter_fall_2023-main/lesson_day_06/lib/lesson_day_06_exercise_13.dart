void main(){
  print(max(4, 5));
}

int max(int a, int b){
  if(a > b){
    return a;
  } else {
    return b;
  }
}