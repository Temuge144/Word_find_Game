void main(){
  print(youAreWonderful('Tsenguun'));
}

String youAreWonderful(String name){
  return "you're wonderful, $name";
}