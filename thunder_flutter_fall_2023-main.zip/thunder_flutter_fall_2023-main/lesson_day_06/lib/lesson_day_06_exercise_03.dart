void main(){
  print(ex01(6, -5));
}
String ex01(int x, int y){
  int c = x * x - 2*x*y + y*y;
  if (c < 10){
    return 'this number is less than 10';
  } else {
    return 'this number is greater than 10';
  }
}