void main(){
  print(isOdd(5));
}

bool isOdd(int a){
  if(a % 2 == 0){
    return false;
  } else {
    return true;
  }
}