void main(){
  print(ex01(7, 8));
}
int ex01(int x, int y){
  int z = x * x + 2 * y + y * y;
  return z;
}