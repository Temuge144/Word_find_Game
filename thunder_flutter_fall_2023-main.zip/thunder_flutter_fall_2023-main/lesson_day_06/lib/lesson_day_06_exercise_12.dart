void main(){
  print(square(4));
}

int square(int a){
  int b = a * a;
  return b;
}