void main(){
 print('dart lesson day 06');
 print('dart lists');
 print('dart functions');

 // int a = 1;
 // int b = 2;
 // int c = 3;
 // int d = 4;
 List<int> gahainuud = [1, 2, 3, 4];
 print(gahainuud);
 List<String> tortnuud = ['Apple Pie', 'Cherry Pie', 'Cake', 'Cheese cake'];
 print(tortnuud);
 List<double> butarhaiToonuud = [3.5, 4.5, 7.8, 9.78];
 print(butarhaiToonuud);
 List<bool> Unenhudal = [true, false, true, false];
 print(Unenhudal);

 print(gahainuud.length);
 print(gahainuud[2]);

 for (int i = 0; i < gahainuud.length; i++){
   print(gahainuud[i]);
 }

 String cupCake = 'Cup cake';
 tortnuud.add(cupCake);
 print(tortnuud);

 tortnuud.remove('Cake');
 print(tortnuud);

 butarhaiToonuud[0] = 5.5;
 print(butarhaiToonuud);
}