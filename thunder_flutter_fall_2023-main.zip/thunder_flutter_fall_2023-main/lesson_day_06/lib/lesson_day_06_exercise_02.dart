void main(){
  print(ex01(6, 6, 7));
}
int ex01(int a, int b, int c){
  int z = a*a*a + 3 * a * b  + 3 * a * c + 3 * b * c + b*b*b + c*c*c;
  return z;
}