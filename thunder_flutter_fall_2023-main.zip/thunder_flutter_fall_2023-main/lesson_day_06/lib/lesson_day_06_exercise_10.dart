import 'dart:math';

void main(){
  print(calculateSquareAre(10.5));
}


double calculateSquareAre(double x, {double y = 2.0}) {
  return x * y;
  }