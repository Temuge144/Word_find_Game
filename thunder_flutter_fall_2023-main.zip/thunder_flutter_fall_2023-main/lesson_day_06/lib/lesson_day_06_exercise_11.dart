void main(){
  print(getLength('abcd'));
}

int getLength(String a){
  int b = a.length;
  return b;
}