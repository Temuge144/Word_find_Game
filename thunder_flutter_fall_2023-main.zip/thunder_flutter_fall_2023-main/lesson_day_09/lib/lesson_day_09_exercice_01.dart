void main() {
  final Vehicle color = Vehicle('blue');
  print(color.drive());
  final Car honk = Car('red');
  print(honk.honk());
}

class Vehicle {
  String color;
  Vehicle(this.color);

  String drive() {
    return "I'm a vehicle with $color";
  }
}

class Car extends Vehicle {
  Car(super.color);
  String honk() {
    return 'Beep Beep Beep';
  }
}