void main(){
  final Building floor = Building(20);
  print(floor._floors);
  final Apartment floors = Apartment(25, 20);
  floors.setfloors = 45;
  print(floors.getfloors);
  print(floors.unitsPerFloor);

}

class Building {
  int _floors;
  Building(this._floors);

  int get getfloors {
    return _floors;
  }

  set setfloors(int floors){
    if (floors > 0){
      _floors = floors;
    }
  }
}

class Apartment extends Building {
  int unitsPerFloor;
  Apartment(this.unitsPerFloor, super._floors);
}