void main(){
  final Printer printer = Printer();
  print(printer.printData());
  final ColorPrinter printerclr = ColorPrinter();
  print(printerclr.printlnColor());
}

class Printer {
  String printData(){
    return "Printing data";
  }
}

class ColorPrinter extends Printer {
  String printlnColor(){
    return "Printing in color";
  }
}