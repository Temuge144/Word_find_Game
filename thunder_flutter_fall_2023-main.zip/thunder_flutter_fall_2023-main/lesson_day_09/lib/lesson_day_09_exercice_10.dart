void main(){
  final ScientificCalculator scientificCalculator = ScientificCalculator(12, 5);
  print(scientificCalculator.add());
  print(scientificCalculator.subtract());
  print(scientificCalculator.sqrt());
}

class Calculator {
  int a;
  int b;

  Calculator(this.a, this.b);
  int add(){
    return this.a + this.b ;
  }


  int subtract(){
    return this.a - this.b ;
  }
}

class ScientificCalculator extends Calculator {
  ScientificCalculator(super.a, super.b);
  double sqrt(){
    if(a <= 0){
      print('Negative value given for square root.');
    }
    return this.a * 0.5;
  }
}