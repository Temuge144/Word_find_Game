void main(){
  final Person A = Person('Fredrin');
  A.greet();
  final Employee B = Employee('Brim');
  B.greet();
}

class Person {
  String name;
  Person(this.name);

  void greet() {
    print("My name is $name");
  }
}

class Employee extends Person {
  Employee(super.name);



  @override
  void greet() {
    super.greet();
  }
}