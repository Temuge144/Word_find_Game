void main(){
  final Gadget gadget = Gadget('Iphone', 'USA');
  print(gadget.TurnOn());
  print(gadget.charge());
  final SmartPhone iphone = SmartPhone('Iphone', 'USA');
  print(iphone.TurnOn());
  print(iphone.charge());
}

class Gadget {
  String name;
  String state;
  Gadget(this.name, this.state);
  
  String TurnOn(){
    return "I'm on";
  }
  
  String charge(){
    return "Charging Gadget";
  }
}

class SmartPhone extends Gadget {
  SmartPhone(super.name, super.state);
  @override
  String TurnOn() {
    return "SmartPhone turns on";
  }

  String charge(){
    return "Charging SmartPhone";
  }
}