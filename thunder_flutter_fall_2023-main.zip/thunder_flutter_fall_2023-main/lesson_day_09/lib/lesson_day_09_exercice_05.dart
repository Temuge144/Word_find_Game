void main(){
  final Shape shape = Shape('Circle');
  print(shape.about());
  final Circle radius = Circle(12, 'Circle');
  print(radius.about());
}

class Shape {
  String name;
  Shape(this.name);

  String about(){
    return "My name is $name";
  }
}

class Circle extends Shape {
  double radius;
  Circle(this.radius, super.name );
  @override
  String about() {
    return "My name is $name. I have a radius of $radius";
  }
}