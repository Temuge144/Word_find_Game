void main(){
  final Computer computer = Computer('fujitsu', 16);
  print(computer.brand);
  print(computer.ramSize);
  final Laptop laptop = Laptop(100, false, 'imac', 4);
  print(laptop.brand);
  print(laptop.ramSize);
  print(laptop.batteryLife);
  print(laptop.isTouchScreen);
}

class Computer {
  String brand;
  double ramSize;
  Computer(this.brand, this.ramSize);
  
  String Boot(){
    return "Computer boots up";
  }
  
  String ShutDown(){
    return "Computer shuts down";
  }
}

class Laptop extends Computer {
  int batteryLife;
  bool isTouchScreen;
  Laptop(this.batteryLife, this.isTouchScreen, super.brand, super.ramSize);
  
  String fold(){
    return "Laptop is folded";
  }
}