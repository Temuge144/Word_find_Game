void main(){
  final Vehicle color = Vehicle('blue');
  print(color.drive());
  final Bike bike = Bike('red');
  print(bike.drive());
}

class Vehicle {
  String color;
  Vehicle(this.color);

  String drive() {
    return "I'm a vehicle with $color";
  }
}

class Bike extends Vehicle {
  Bike(super.color);
  @override
  String drive() {
    return  "The bike is pedaling";
  }
}