void main(){
  final Vehicle color = Vehicle('blue');
  print(color.drive());
  final Car lamborghini = Car('Yellow');
  print(lamborghini.drive());
}

class Vehicle {
  String color;
  Vehicle(this.color);

  String drive() {
    return "I'm a vehicle with $color";
  }
}

class Car extends Vehicle {
  Car(super.color);
}