class Parent {
  void show(){
    print("I'm from Parent class");
  }
}

class Child extends Parent {
  void display(){
    print("I'm from Child class");
  }
}

void main(){
  final Parent parent = Parent();
  parent.show(); // Only from Parent

  final Child child = Child();
  child.show(); // from Parent
  child.display(); // from Child

  // parent.daisplay() // It is not possible
}