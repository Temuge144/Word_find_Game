void main(){
  print('lesson day 08 class constructor');
  final Vehicle bicycle = Vehicle('Bicycle', 2); // bicycle object - constructor
  print(bicycle.type);
  print(bicycle.wheels);
  final Vehicle car = Vehicle('Car', 4);
  print(car.type);
  print(car.wheels);
}

class Vehicle {
  String? type;
  int? wheels;

  Vehicle(String type, int wheels){
    this.type = type;
    this.wheels = wheels;
  }
}