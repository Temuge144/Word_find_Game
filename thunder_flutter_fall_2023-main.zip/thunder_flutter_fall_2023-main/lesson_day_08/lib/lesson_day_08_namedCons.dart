void main(){
  print('dart class named cons');
  final Building mnTower = Building('MN Tower', 20);
  print(mnTower.stock);
  print(mnTower.name);

  final Building newBuilding = Building.createBuilding('New Building', 10);
  print(newBuilding.stock);
  print(newBuilding.name);

  final Building defaultBuilding =
      Building.createDefaultBuilding('Default New Building');
  print(defaultBuilding.stock);
  print(defaultBuilding.name);
}

class Building {
  String name;
  int stock;

  Building.createBuilding(this.name, this.stock); // named constructor

  Building.createDefaultBuilding(this.name, [this.stock = 10]);

  Building(this.name, this.stock);
}