import 'package:lesson_day_08/lesson_day_08.dart';

void main(){
  print('Lesson day 08 class constructor');
  final Building mnTower = Building('MN Tower', 20);
  print(mnTower.stock);
  print(mnTower.name);
}

class Building {
  String name;
  int stock;
  Building (this.name, this.stock);
}