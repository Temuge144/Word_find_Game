void main(){
  final Shape square = Shape('Square');
  square.changeShape('Square');
  print(square);
  print('is type of square');
  print(square.isTypeOf('Square'));
  print('is type of circle');
  print(square.isTypeOf('circle'));
  print('is type of Circle');
  print(square.isTypeOf('Circle'));
  print('is type of Triangle');
  print(square.isTypeOf('Triangle'));

}

class Shape {
  String? type;

  Shape(this.type);

  void changeShape(String type){
    this.type = type;
  }

  bool isTypeOf(String type){
    return type == this.type;
  }


  @override
  String toString() {
    return 'This is a ${this.type}';
  }
}