void main() {
  final Song artist = Song('The Alchemist', 'Paulo Coelho');
}

class Song {
  String _name;
  String _title;

  String get getName {
    return _name;
  }

  String get getTitle {
    return _title;
  }

  set setName(String name) {
    _name = name;
  }

  set setTitle(String title) {
    _title = title;
  }

  Song(this._title, this._name);

  Song.artist(this._title, this._name);

  @override
  String toString() {
    // TODO: implement toString
    return 'Song {title: $_title, artist: $_name}';
  }
}
