void main(){
  final Vehicle car = Vehicle('Car', 4);
  print(car.type);
  print(car.wheels);
  print(car);
  final Vehicle bicycle = Vehicle('Bicycle', 2);
  print(bicycle.type);
  print(bicycle.wheels);
  print(bicycle);
}

class Vehicle {
  String? type;
  int? wheels;

  Vehicle(String type, int wheels){
    this.type = type;
    this.wheels = wheels;
  }

  @override
  String toString(){
    return 'Vehicle{type: $type, wheels: $wheels}';
  }
}