import 'package:lesson_day_08/lesson_day_08_Exercise_04.1.dart';

void main(){
  final Song artist = Song('The Alchemist', 'Paulo Coelho');
  print(artist.getTitle);
  print(artist.getName);
  print(artist);
  artist.setTitle = 'The Alchemist';
  artist.setName = 'Paulo Coelho';
  print(artist.getTitle);
  print(artist.getName);
  print(artist);
}