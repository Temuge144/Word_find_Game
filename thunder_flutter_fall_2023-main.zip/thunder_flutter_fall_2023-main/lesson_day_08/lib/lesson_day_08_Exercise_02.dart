void main(){
  final User human1 = User('John', 30);
  print(human1.name);
  print(human1.age);
  print(human1);
  final User human2 = User('Khangai', 41);
  print(human2.name);
  print(human2.age);
  print(human2);
}

class User {
  String? name;
  int? age;

  User(String name, int age){
    this.name = name;
    this.age = age;
  }

  @override
  String toString(){
    return 'User{name: $name, wheels: $age}';
  }
}