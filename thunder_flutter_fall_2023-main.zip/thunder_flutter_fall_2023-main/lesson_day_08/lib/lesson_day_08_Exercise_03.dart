void main(){
  final Student user1 = Student.user1('Tsenguun', 11);
  print(user1.name);
  print(user1.grade);
  print(user1);
  final Student user2 = Student.user2('Odko', 11);
  print(user2.name);
  print(user2.grade);
  print(user2);
  final Student user3 = Student.user3('Ganaa', 11);
  print(user3.name);
  print(user3.grade);
  print(user3);
}

class Student {
  String? name;
  int? grade;

  Student.user1(this.name, this.grade);

  Student.user2(this.name, this.grade);

  Student.user3(this.name, this.grade);

  @override
  String toString(){
    return 'Student{name: $name, grade: $grade';
  }
}