import 'package:flutter/material.dart';
import 'package:lesson_day_17_flutter/navigation.dart';
import 'package:lesson_day_17_flutter/navigation_page_two.dart';

class NavigationPageOne extends StatelessWidget {
  const NavigationPageOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page One'),
        leading: ElevatedButton(
          onPressed: (){
            Navigator.pop(
                context,
                MaterialPageRoute(
                    builder: (context) => const NavigationHome()));
          },
          child: Icon(Icons.arrow_back),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                onPressed:  () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => NavigationPageTwo()));
                },
                child: Text('Go to Page Two'),
            ),
            ElevatedButton(
                onPressed:  () {
                  Navigator.pop(
                      context,
                      MaterialPageRoute(
                          builder: (context) => NavigationHome()));
                },
                child: Text('Go to Home Two'),
            ),
          ],
        ),
      ),
    );
  }
}
