import 'package:flutter/material.dart';
import 'package:lesson_day_17_flutter/navigation_page_one.dart';
import 'navigation.dart';

class NavigationPageTwo extends StatelessWidget {
  const NavigationPageTwo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page Two'),
        leading: ElevatedButton(
          onPressed: () {
            Navigator.pop(
                context,
                MaterialPageRoute(
                    builder: (context) => const NavigationHome()));
          },
          child: Icon(Icons.arrow_back),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                    context,
                    MaterialPageRoute(
                        builder: (context) => NavigationPageOne()));
              },
              child: Text('Go to Page One'),
            ),
          ],
        ),
      ),
    );
  }
}
