void main() {
  //exercise 01
  int myage = 16;
  print(myage);
  //exercise 02
  double averageAge = 16;
  print((myage + averageAge) / 2);
  //exercise 03
  int testnumber = 45;
  int evenOdd = testnumber % 2;
  print(evenOdd);
  //exercise 04
  int dogs = 9;
  print(dogs + 1);
  //exercise 05
  int age = 16;
  print(age);
  age = 30;
  print(age);
  //exercise 06
  const x = 46;
  const y = 10;
  const answer1 = (x * 100) + y;
  const answer2 = (x * 100) + (y * 100);
  const answer3 = (x * 100) + (y / 10);
  print(answer1);
  print(answer2);
  print(answer3);
  //exercise 07
  const double rating1 = 5.6;
  const double rating2 = 7.4;
  const double rating3 = 9.5;
  const double averageRating = (rating1 + rating2 + rating3)/3;
  print(averageRating);
}
