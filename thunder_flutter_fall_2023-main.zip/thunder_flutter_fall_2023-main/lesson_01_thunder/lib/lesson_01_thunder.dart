import 'dart:math';
void main(){
  print('Hello Thunder Team'); // this is a comment
  /**
   * this is multiline comment
   * this is multiline comment
   */
  print(2); //2
  print(2*3); //6
  print(2+4); //6
  print(4/2); //2.0

  //modulo operations
  print(4 % 2); //0
  print(4 % 3); //1

  // order of operations
  print(4 + 5 + 3 * 6 / 2); //18

  print((4 + 5) + (3 + 6) * 2); //27

  print(sin(45 * pi/180)); //0.7
  print(cos(135 * pi/180)); //-0,7

  print(sqrt(9)); //3 square root of 9
  print(max(100, 99)); // 100

  print(sqrt(2)/2); //0.7
  print(sin(45 * pi/180)); //0.7

  //variable - хувьсагч
  String thirstbox='alim';
  print(thirstbox);

  //string interpolation
  print('$thirstbox');
  print('$thirstbox');
  print('$thirstbox amttai');
  print('$thirstbox unetei');

  // data types
  int too = 15;
  print(too);
  double butarhaiToo = 15.6;
  print(butarhaiToo);
  bool ToBeOrNotToBe = true; // үнэн худал
  print(ToBeOrNotToBe);
  bool mongolianGovermentIsBad = true; //үнэн
  print(mongolianGovermentIsBad);
  bool foxIsYellow = false; // худал
  print(foxIsYellow);

  String name = 'Tsenguun'; // text
  print(name);

  //huvsagchiin utgiig oorchloh
  name = 'zaker';
  print(name);

  // delhiin tatah huchnii togtmol 9.81
  const gravitationConstant = 9.81; // const ni huvsagch oorchloh bolomjgui bolgon
  print(gravitationConstant);
  // gerliin hurd - 299 792 458 m/s
  const gerliinhurd = 299792458;
  print(gerliinhurd);
}
