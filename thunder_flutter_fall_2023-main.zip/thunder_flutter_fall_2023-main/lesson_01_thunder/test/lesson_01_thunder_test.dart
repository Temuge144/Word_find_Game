import 'package:lesson_01_thunder/lesson_01_thunder.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
