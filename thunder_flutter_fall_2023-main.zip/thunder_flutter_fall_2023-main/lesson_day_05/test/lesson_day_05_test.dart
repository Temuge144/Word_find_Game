import 'package:lesson_day_05/lesson_day_05_Exercises_01.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
