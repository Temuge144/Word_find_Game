import 'dart:io';

void main() {
  int n = int.parse(stdin.readLineSync()!);
  bool found = false;
  while (!found) {
    for (int i = 1; i <= n; i++) {
      for (int t = 2; t <= i; t++) {
        if (i % t == 0) {
        } else {
          found = true;
          print(t);
        }
      }
    }
  }
}
