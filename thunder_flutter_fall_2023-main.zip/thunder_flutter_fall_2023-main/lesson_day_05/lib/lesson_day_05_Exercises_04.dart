import 'dart:io';

void main() {
  int num = int.parse(stdin.readLineSync()!);
  int i = 1;
  if (num >= 5 && num <= 20) {
    while (i <= num) {
      print(i * -1);
      i++;
    }
  } else {
    print('Invilad number');
  }
}