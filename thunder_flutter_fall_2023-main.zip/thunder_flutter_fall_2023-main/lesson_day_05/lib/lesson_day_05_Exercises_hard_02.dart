import 'dart:io';

void main(){
  int n = int.parse(stdin.readLineSync()!);
  int Fn = 0;
  int Fn1 = 0;
  int Fn2 = 1;

  while (Fn <= n){
    Fn = Fn1 + Fn2;
    print(Fn);
    Fn1 = Fn2;
    Fn2 = Fn;
  }
}