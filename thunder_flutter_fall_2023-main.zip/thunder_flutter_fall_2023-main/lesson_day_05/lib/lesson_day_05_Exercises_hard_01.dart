import 'dart:io';

void main(){
  print('n = ');
  int n = int.parse(stdin.readLineSync()!);
  for(int i = 1; i <= n; i++){
    String row = '';
    for (int v = i; v <= n; v++) {
      row += ' ';
    }
    for(int p = 1; p <= i; p++) {
      row += '$i ';
    }
    print(row);
  }
}