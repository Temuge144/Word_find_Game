import 'dart:io';

void main() {
  //1
  int num1 = int.parse(stdin.readLineSync()!);
  if (num1 >= 5 && num1 <= 20) {
    for (int i = 0; i <= num1; i++) {
      print('WHILE LOOP');
    }
  } else {
    print('Invilad number');
  }
  //2
  int num2 = int.parse(stdin.readLineSync()!);
  if (num2 >= 5 && num2 <= 20) {
    for (int i = 1; i <= num2; i++) {
      print(i);
    }
  } else {
    print('Invilad number');
  }
  //3
  int num3 = int.parse(stdin.readLineSync()!);
  if (num3 >= 5 && num3 <= 20) {
    for (int i = 1; i <= num3; i++) {
      print(i + num3);
    }
  } else {
    print('Invilad number');
  }
  //4
  int num4 = int.parse(stdin.readLineSync()!);
  if (num4 >= 5 && num4 <= 20) {
    for (int i = 1; i <= num4; i++) {
      print(i * -1);
    }
  } else {
    print('Invilad number');
  }
  //5
  int num = int.parse(stdin.readLineSync()!);
  if (num >= 5 && num <= 20) {
    for (int i = 1; i <= num; i++) {
      if (i % 2 == 0){
        print('$i is even number');
      } else if (i % 2 == 1) {
        print('$i is odd number');
      }
    }
  } else {
    print('Invilad number');
  }
}