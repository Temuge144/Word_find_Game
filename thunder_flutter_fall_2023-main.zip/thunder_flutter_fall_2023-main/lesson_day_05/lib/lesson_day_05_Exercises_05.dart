import 'dart:io';

void main() {
  int num = int.parse(stdin.readLineSync()!);
  int i = 1;
  if (num >= 5 && num <= 20) {
    while (i <= num) {
      if (i % 2 == 0){
        print('$i is even number');
        i++;
      } else if (i % 2 == 1) {
        print('$i is odd number');
        i++;
      }
    }
  } else {
    print('Invilad number');
  }
}