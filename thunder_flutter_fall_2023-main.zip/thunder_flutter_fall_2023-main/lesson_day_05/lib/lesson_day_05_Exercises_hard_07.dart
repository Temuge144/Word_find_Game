import 'dart:math';
import 'dart:io';

void main(){
  Random random = new Random();
  int randomNumber = random.nextInt(100);
  print(randomNumber);
  print('Too oruulna uu: ');
  int t = int.parse(stdin.readLineSync()!);

  while(randomNumber != t){
    if(randomNumber > t){
      print('Its is cold');
    } else if (randomNumber < t){
      print('Its is hot');
    }
    print('Dahin too oruulna uu');
    t = int.parse(stdin.readLineSync()!);
  }

  print('Yes you guessed the number');
}