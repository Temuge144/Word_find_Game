import 'dart:io';
void main(){
  print('get input from keyboard');
  String? input = stdin.readLineSync();
  print('you have given a number: $input');

  // neree asuugaad tuuniig my name gsn huvisagchid onoogooroi
  print('say your name');
  String? myname = stdin.readLineSync();
  print('your name is $myname');
  print('nice to meet you');

  print('how old are you?');
  String? yourage = stdin.readLineSync();
  print('your age is $yourage');

  // hereglegch 2 too avaad tuunii niilberiig ol
  print('give me your first number');
  String? fnum = stdin.readLineSync();
  int a = int.parse(fnum!);
  print('give me your second number');
  String? snum = stdin.readLineSync();
  int b = int.parse(snum!);
  print(fnum);
  print(snum);
  print('Sum: ${a + b}');
}