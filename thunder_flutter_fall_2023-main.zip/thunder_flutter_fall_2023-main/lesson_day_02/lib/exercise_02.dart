void main(){
  //1
  print('Example 1:');
  int a = 1;
  int b = 15;
  int c = 5;
  int d = 50;
  double e = 2.0;
  print('Example: $a');
  print('Sum: $b');
  print('Difference: $c');
  print('Product: $d');
  print('Quotient: $e');
  //2
  print('');
  print('');
  print('Example 2:');
  String fname = 'John';
  String lname = 'Doe';
  String funame = 'John Doe';
  print('Fist Name: $fname');
  print('Sum: $lname');
  print('Difference: $funame');
  //3
  print('');
  print('');
  print('Example 3:');
  int wk = 7;
  double pi = 3.14159265359;
  print('Day in a week: $wk');
  print('Value of pi: $pi');
}