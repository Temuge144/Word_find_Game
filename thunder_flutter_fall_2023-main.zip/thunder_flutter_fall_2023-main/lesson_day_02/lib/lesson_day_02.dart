// lesson day 2

import 'dart:html';
import 'dart:math';

void main(){
  print('lesson day - 02');
  // buhel toon huvsagch
  int a = 5;
  print(a);
  //butarhai too
  double b = 2.5;
  print(b);
  // text ogson tebdegt
  String c = 'hello';
  print(c);
  //unen hudal
  bool d = true;
  print(d);
  //aritmetic operations
  print(4.5 + 5.5);
  print(4.5 * 8);
  print(5.6 - 2.3);
  print(8/2);
  //module operations
  int rest = 8 % 4;
  print(rest);
  //change variable values
  a = 10;//change variable value 5 into 10
  print(a);
  c ='2.5';
  print(c);
  //dart math gedeg sang ashiglah
  print(sin(45 * pi/180));
  print(cos(45 * pi/180));
  print(max(4, 5));
}