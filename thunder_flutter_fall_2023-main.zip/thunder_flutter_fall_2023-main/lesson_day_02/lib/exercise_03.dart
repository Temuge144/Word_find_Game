import 'dart:io';

void main() {
  //1
  print('1 start');
  print('enter an integer:');
  String? imput = stdin.readLineSync();
  int a = int.parse(imput!);
  if (a % 2 == 0) {
    print('$a is even.');
  } else {
    print('$a is odd');
  }
  //2
  print('2 start');
  print('enter an integer:');
  String? num = stdin.readLineSync();
  int b = int.parse(num!);
  if (b > 0) {
    print('$b is positive.');
  } else if (b == 0) {
    print('$b is zero');
  } else {
    print('$b negative.');
  }
  //3
  print('3 start');
  print('enter the first number:');
  String? num2 = stdin.readLineSync();
  int d = int.parse(num2!);
  print('enter the second number:');
  String? num3 = stdin.readLineSync();
  int e = int.parse(num3!);
  if (d > e) {
    print('$d is greater than $e');
  } else if (d == e) {
    print('$d is equal $e');
  } else {
    print('$e is greater thab $d');
  }
  //4
  print('4 start');
  print('enter your score:');
  String? num4 = stdin.readLineSync();
  int p = int.parse(num4!);
  if (p < 60){
    print('your grade if F.');
  }
  if (p < 69 && p > 60){
    print('your grade if D.');
  }
  if (p < 79 && p > 70){
    print('your grade if C.');
  }
  if (p < 89 && p > 80){
    print('your grade if B.');
  }
  if (p < 100 && p > 90){
    print('your grade if A.');
  }
  //5
  print('5 start');
  print('enter the first number');
  String? num5 = stdin.readLineSync();
  int r = int.parse(num5!);
  print('enter the operator');
  String? operator = stdin.readLineSync();
  print('enter the second number');
  String? num6 = stdin.readLineSync();
  int t = int.parse(num6!);
  if (operator == '+'){
    print('result ${r + t}');
  }
  if (operator == '-') {
    print('result ${r - t}');
  }
  if (operator == '*') {
    print('result ${r * t}');
  }
  if (operator == '/') {
    print('result ${r / t}');
  } else {
    print('invalid operator');
  }
}
