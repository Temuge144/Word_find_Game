void main(){
  String name = 'John';
  String age = '30';
  String height = '5.9';
  String country = 'USA';
  String week = '7';
  print('Name: $name');
  print('Age: $age');
  print('Height: $height');
  print('Country: $country');
  print('Day in a week: $week');
}