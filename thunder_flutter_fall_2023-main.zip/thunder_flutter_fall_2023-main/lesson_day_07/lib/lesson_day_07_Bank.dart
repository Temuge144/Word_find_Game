void main(){
  final BankCustomer tsenguun = BankCustomer();
  tsenguun.accountNumber= 566877890;
  tsenguun.accountBlance = 1000000;
  tsenguun.customerName = 'Batdorj Tsenguun';
  tsenguun.showBlance();
}

class BankCustomer {
  int? accountNumber;
  int? accountBlance;
  String? customerName;

  void showBlance(){
    print('Bank account number is $accountNumber. '
        'account blance : $accountBlance.'
        ' costomer name is $customerName.');
  }
}