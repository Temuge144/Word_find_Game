void main(){
  final Rectangle rc = Rectangle();
    print(rc.p(10, 5));
}

class Rectangle {
  int p (int width, int heightProperty){
    return width * heightProperty;
  }
}