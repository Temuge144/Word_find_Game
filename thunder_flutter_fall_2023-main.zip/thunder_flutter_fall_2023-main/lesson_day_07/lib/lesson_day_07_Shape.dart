void main(){
  final Shape typeColor = Shape();
  typeColor.type = 'circle';
  typeColor.color = 'red';
  typeColor.ShowTypeAndColor();
}

class Shape {
  String type = 'type';
  String color = 'color';

  void ShowTypeAndColor(){
    print('this shape is $type. '
        'this $type color is $color.');
  }
}