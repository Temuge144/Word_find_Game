void main(){
  final Book tyt = Book();
  tyt.title = 'Robinson Crusoe';
  tyt.author = 'Daniel Defoe';
  tyt.publishedYear = 1719;
  tyt.showBookInfo();
}

class Book {
  String? title;
  String? author;
  int? publishedYear;

  void showBookInfo(){
    print('This book title is $title. '
        'book author name is $author.'
        ' this book published year is $publishedYear.');
  }
}