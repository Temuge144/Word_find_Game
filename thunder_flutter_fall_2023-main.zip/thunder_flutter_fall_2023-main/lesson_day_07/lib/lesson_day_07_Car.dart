void main(){
  final Car tyt = Car();
  tyt.make = 'Toyota';
  tyt.model = 'Land Cruiser';
  tyt.year = 2021;
  print(tyt.make);
  print(tyt.model);
  print(tyt.year);
}

class Car {
  String make = 'make';
  String model = 'modelr';
  int year = 2000;
}