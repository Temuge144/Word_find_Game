void main(){
  final People tsenguun = People();
  tsenguun.name = 'Tsenguun';
  tsenguun.age = 16;
  tsenguun.email = 'tsenguuntseku02@gmail.com';
  print(tsenguun.name);
  print(tsenguun.age);
  print(tsenguun.email);
}

class People {
  String name = 'name';
  int age = 1;
  String email = 'email@gmail.com';
}