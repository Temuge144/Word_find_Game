void main(){
  final Employee irgenA = Employee();
  irgenA.jobTitle = 'Finance Manager';
  irgenA.location = 'Ulaanbaatar';
  irgenA.overtime = 7;
  irgenA.salary = 5000;
}

class Employee {
  String? jobTitle;
  String? location;
  int? salary;
  int? overtime;

  void Timer
}