import 'dart:math';

void main() {
  final Circle crcl = Circle();
  print(crcl.circumference());
}

class Circle {
  double radius = 5;
  double circumference() {
    return (2 * pi) * radius;
  }
}
