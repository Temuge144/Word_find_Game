void main(){
  final Calculator cl = Calculator();
  print(cl.addition(10, 5));
  print(cl.subtraction(10, 5));
  print(cl.multiplication(2, 3));
  print(cl.division(6, 2));
}

class Calculator {
  int addition (int a, int b){
    return a + b;
  }

  int subtraction (int a, int b){
    return a - b;
  }

  int multiplication (int a, int b){
    return a * b;
  }

  double division (int a, int b){
    return a / b;
  }
}