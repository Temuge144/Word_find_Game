void main(){
  final TemperatureConverter ctof = TemperatureConverter();
  print(ctof.celsiusToFahrenheit());
  print(ctof.FahrenheitTocelsius());
}

class TemperatureConverter {
  double c = 10;
  double f = 100;
  double celsiusToFahrenheit(){
    return (c * 9 / 5 ) + 32;
  }
  double FahrenheitTocelsius(){
    return (f-32) * (5 / 9);
  }
}