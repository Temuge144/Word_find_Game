void main(){
  final Student khangai = Student();
  khangai.name = 'Khangaikhuu';
  khangai.studentid = 12345678;
  khangai.grade = 78.5;
  khangai.showStudentInfo();
}

class Student {
  String? name;
  int? studentid;
  double? grade;

  void showStudentInfo(){
    print('the student name is $name. '
        'she has student id : $studentid.'
        ' she has the grade $grade.');
  }
}