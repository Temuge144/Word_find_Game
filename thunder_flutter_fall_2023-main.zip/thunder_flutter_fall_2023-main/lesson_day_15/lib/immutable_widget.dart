import 'package:flutter/material.dart';
import 'dart:math';

class ImmutableWedgit extends StatelessWidget {
  const ImmutableWedgit({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Welcome to Flutter',
        ),
        centerTitle: true,
        actions: [
          Icon(Icons.edit),
        ],
      ),
      body: Container(
        color: Colors.green,
        child: Center(
          child: Transform.rotate(
            angle: 180 / pi,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(color: Colors.purple, borderRadius: BorderRadius.circular(20), boxShadow: [
                BoxShadow(
                  color: Colors.deepPurple.withAlpha(120),
                  spreadRadius: 4,
                  blurRadius: 15,
                  offset: Offset.fromDirection(1.0, 30),
                )
              ]),
              child: Padding(
                padding: EdgeInsets.all(50.0),
                child: _buildShinyCircle(),
              ),
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.indigo,
          child: Text("I'm a drawer"),
        ),
      ),
    );
  }

  Widget _buildShinyCircle() {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            Colors.lightBlueAccent,
            Colors.blueAccent,
          ],
          center: Alignment(-0.3, -0.5),
        ),
        boxShadow: [
          BoxShadow(blurRadius: 20),
        ],
      ),
    );
  }
}
