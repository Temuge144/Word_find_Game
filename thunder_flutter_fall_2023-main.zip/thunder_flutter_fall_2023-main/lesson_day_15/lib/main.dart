import 'package:flutter/material.dart';
import 'package:lesson_day_15/basic_screen.dart';
import 'package:lesson_day_15/immutable_widget.dart';
import 'package:lesson_day_15/profile_screen.dart';
import 'package:lesson_day_15/stop_watch.dart';

void main() {
  runApp(MaterialApp(
    home: StopWatch(),
  ));
}
