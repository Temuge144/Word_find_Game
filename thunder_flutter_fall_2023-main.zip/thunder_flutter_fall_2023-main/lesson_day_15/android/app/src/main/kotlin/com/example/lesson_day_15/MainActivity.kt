package com.example.lesson_day_15

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
