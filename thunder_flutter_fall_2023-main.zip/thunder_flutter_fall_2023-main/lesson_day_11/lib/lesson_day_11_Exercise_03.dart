abstract class Media {
  String title;
  int duration;

  Media(this.title, this.duration);

  String play();
  String stop();
}

class Song extends Media {
  String artist;

  Song(super.title, super.duration, this.artist);

  @override
  String play() {
    return 'Playing $artist by $title';
  }

  @override
  String stop(){
    return 'Stopped $artist by $title';
  }
}

class Movie extends Media {
  String director;

  Movie(super.title, super.duration, this.director);

  @override
  String play() {
    return 'Playing The $title by $director';
  }

  @override
  String stop(){
    return 'Stopped The $title by $director';
  }
}

void main(){
  final Song song = Song('Queen', 3, 'Bohemian Rhapsody');
  print(song.play());
  print(song.stop());

  final Movie movie = Movie('ShawShank', 3, 'Frank Darabont');
  print(movie.play());
  print(movie.stop());
}