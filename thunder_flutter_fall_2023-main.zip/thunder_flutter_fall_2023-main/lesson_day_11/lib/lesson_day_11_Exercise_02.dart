abstract class Weather {
  double temperature;
  double humidity;

  Weather(this.temperature, this.humidity);

  String description();
  String advice();
}

class Rainy extends Weather {
  Rainy(super.temperature, super.humidity);

  @override
  String advice() {
    return 'Bring an umbrella';
  }

  @override
  String description() {
    return 'Today is rainy day';
  }
}

class Sunny extends Weather {
  Sunny(super.temperature, super.humidity);

  @override
  String advice() {
    return 'Wear sunscreen';
  }

  @override
  String description() {
    return 'Today is sunny day';
  }
}

class Windy extends Weather {
  Windy(super.temperature, super.humidity);

  @override
  String advice() {
    return 'Wear a jacket';
  }

  @override
  String description() {
    return 'Today is windy day';
  }
}

void main(){
  final Rainy rainy = Rainy(20.0, 80.0);
  print('Temperature: ${rainy.temperature}, Humidity: ${rainy.humidity}');
  print(rainy.advice());

  final Sunny sunny = Sunny(30.0, 50.0);
  print('Temperature: ${sunny.temperature}, Humidity: ${sunny.humidity}');
  print(sunny.advice());

  final Windy windy = Windy(15.0, 60.0);
  print('Temperature: ${windy.temperature}, Humidity: ${windy.humidity}');
  print(windy.advice());
}