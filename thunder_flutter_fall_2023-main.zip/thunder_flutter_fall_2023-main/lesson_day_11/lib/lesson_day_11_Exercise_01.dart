abstract class Product {
  int id;
  String name;
  double price;

  Product(this.id, this.name, this.price);

  String displayDetalis();
  String category();
}

class Electronics extends Product {
  Electronics(super.id, super.name, super.price);

  @override
  String displayDetalis(){
    return name;
  }

  @override
  String category(){
    return 'Electronics';
  }
}

class Clothing extends Product {
  Clothing(super.id, super.name, super.price);

  @override
  String displayDetalis(){
    return name;
  }

  @override
  String category(){
    return 'Clothing';
  }
}

class Groceries extends Product {
  Groceries(super.id, super.name, super.price);

  @override
  String displayDetalis(){
    return name;
  }

  @override
  String category(){
    return 'Groceries';
  }
}

void main(){
  final Electronics electronics = Electronics(1, 'Laptop', 1000.0);
  print('ID: ${electronics.id}, Name: ${electronics.displayDetalis()}, Price: ${electronics.price}');
  print('Category: ${electronics.category()}');

  final Clothing clothing = Clothing(2, 'T-Shirt', 20.0);
  print('ID: ${clothing.id}, Name: ${clothing.displayDetalis()}, Price: ${clothing.price}');
  print('Category: ${clothing.category()}');

  final Groceries groceries = Groceries(3, 'Rice', 10.0);
  print('ID: ${groceries.id}, Name: ${groceries.displayDetalis()}, Price: ${groceries.price}');
  print('Category: ${groceries.category()}');
}