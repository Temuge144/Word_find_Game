import 'package:lesson_day_11/lesson_day_11_Exercise_01.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
