import 'dart:io';

void main() {
  print('start 2');
  print('first number');
  int num1 = int.parse(stdin.readLineSync()!);
  print('second number');
  int num2 = int.parse(stdin.readLineSync()!);
  print('third number');
  int num3 = int.parse(stdin.readLineSync()!);
  if (num1 > num2 && num1 > num3){
    print('$num1 hamgiin ih too ni');
  } else if (num2 > num1 && num2 > num3){
    print('$num2 hamgiin ih too ni');
  } else {
    print('$num3 hamgiin ih too ni');
  }
  print('end 2');
}