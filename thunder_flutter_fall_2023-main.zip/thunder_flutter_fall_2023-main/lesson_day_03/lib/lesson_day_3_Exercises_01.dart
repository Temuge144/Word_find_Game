import 'dart:io';

void main(){
  print('start 1');
  print('A taliig oruul');
  String? A = stdin.readLineSync();
  print('B taliig oruul');
  String? B = stdin.readLineSync();
  print('C taliig oruul');
  String? C = stdin.readLineSync();
  if (A == B && B == C){
    print("i'ts an equilateral triangle.");
  } else if (A == B || B == C || A == C){
    print("i'ts an isosceles triangle.");
  } else {
    print("i'ts a scalene triangle.");
    print('end 1');
  }
}