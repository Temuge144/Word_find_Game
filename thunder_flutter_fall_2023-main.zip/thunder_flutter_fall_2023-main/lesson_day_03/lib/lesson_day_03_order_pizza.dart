import 'dart:io';

void main(){
  print('Small: 5 USD , Medium: 7 USD , Large: 10 USD');
  print('Please enter your pizza size');
  String? size = stdin.readLineSync();
  print('How many pizza do you want of $size');
  int count = int.parse(stdin.readLineSync()!);
  if (size == 'Small'){
    count = count * 5;
    print('you total payment is: $count');
  } else if (size == 'Medium'){
    count = count * 7;
    print('you total payment is: $count');
  } else {
    count = count * 10;
    print('you total payment is: $count');
  }
}