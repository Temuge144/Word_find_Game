import 'dart:io';

void main(){
  String singleQouted = 'This is a single-quoted string.';
  String doubleQuoted = "This is a double-quoted string.";

  String firstname = 'John';
  String lastname = 'Doe';
  String fullname = firstname + ' ' + lastname;

  String name = ' Alice';
  String greating = 'Hello, World!';

  String text = 'Hello, World!';
  int length = text.length;

  String sentence = ' Dart programming is fun! ';
  String trimmed = sentence.trim();

  String str1 = 'apple';
  String str2 = 'apple';
  bool isEqual = str1 == str2;

  String multiline = '''
  This is a
  multiline
  string
  ''';

  String rawString = r'this is a \n raw string';

  String numberStr = '42';
  int parsedInt = int.parse(numberStr);
  String doubleStr = '45.6';
  double parseDouble = double.parse(doubleStr);

  bool isEven = true;
  bool isOdd = false;

  bool result = (5 == 5);
  result = 6 > 7;
  result = 8 >= 7;
  result = 7 <= 8;
  print(result);
  int age = 24;
  result = 5 < age && age < 25;
  // and (&&) boolean operator
  // true && true = true
  // false && false = false
  // false && true = false
  // true && false = false
  String nationity = 'Mongolian';
  String gender = 'man';
  result = (nationity == 'Mongolian' || gender == 'man');
  // or (||) boolean operator
  // true && true = true
  // false && false = false
  // false && true = true
  // true && false = true
  result = (nationity != 'Mongolian');

  print(result);

  print("Enter an integer");
  int number = int.parse(stdin.readLineSync()!);
  if (number > 0){
    print("$number is positive");
  } else if (number < 0) {
    print("$number is negative");
  } else {
    print("$number is zero.");
  }

  String b = 'Mongolian';
  switch(b) {
    case 'Moroccian':
    print('you are moroccian');
       break;
    case 'Mongolian':
      print('you are mongolian');
      break;
    case 'Turkish':
      print('you are turkish');
      break;
    default: {
      print('your nationality is not included');
      break;
    }
  }

 }