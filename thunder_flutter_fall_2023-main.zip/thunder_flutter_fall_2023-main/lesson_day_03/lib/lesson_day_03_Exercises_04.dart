import 'dart:io';

void main(){
  print('1-7 hurtleh too avaarai');
  int num = int.parse(stdin.readLineSync()!);
  switch(num){
    case 1:
      print('The day is Monday');
      break;
    case 2:
      print('The day is Tuesday');
      break;
    case 3:
      print('The day is Wednesday');
      break;
    case 4:
      print('The day is Thursday');
      break;
    case 5:
      print('The day is Friday');
      break;
    case 6:
      print('The day is Saturday');
      break;
    case 7:
      print('The day is Sunday');
      break;
    default: {
      print('invalid day');
    }
  }
}