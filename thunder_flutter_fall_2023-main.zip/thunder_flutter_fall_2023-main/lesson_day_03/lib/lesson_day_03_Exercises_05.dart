import 'dart:io';

void main(){
  print('Enter a temperature:');
  int tem = int.parse(stdin.readLineSync()!);
  print('Is it in Celsius or Fahrenheit? (C/F)');
  String? CF = stdin.readLineSync();
  double f = tem*9/5+32;
  double c = (tem-32)*5/9;
  if (CF == 'C' ){
    print('$tem℃ is equal to $f℉');
  } else {
    print(' $c℃ equal to $tem℉');
  }
}