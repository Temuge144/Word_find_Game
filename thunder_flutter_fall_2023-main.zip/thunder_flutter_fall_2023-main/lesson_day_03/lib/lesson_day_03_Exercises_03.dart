import 'dart:io';

void main(){
  print('neree oruul');
  String? myName = stdin.readLineSync();
  print('nasaa oruul');
  int myAge = int.parse(stdin.readLineSync()!);
  if (0 < myAge && myAge < 12){
    print("you are a child");
  } else if (13 < myAge && myAge < 19){
    print("you are a teen");
  } else if (20 < myAge && myAge < 64){
    print("you are a adult");
  } else if (65 < myAge){
    print("you are a senior");
  } else {
    print("Invalid age");
  }
}