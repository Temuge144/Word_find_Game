package com.example.lesson_day_13_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
