void main(){
  print('Lesson Day 04 - Loops');

  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');
  // print('hello dart');

  // while loop
  int i = 1;
  while (i <= 10){
    print('$i : Hello Dart');
    // THIS MUST BE HERE!!!
    i = i + 1;
  }

  // for loop
  for(int i = 1; i <= 10; i = i + 1){
    print('$i : hello dart');
  }
}