void main(){
  List numbers = [1, 2, 3, 4, 5];
  int q = 0;
  for (int i = 0; i < numbers.length; i++) {
    q < numbers.length;
    q++;
    print('Element at index $i is $q.');
  }
}