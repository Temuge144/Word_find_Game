void main(){
  List fruits = ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry'];
  for (int i = 0; i < fruits.length; i++){
    print(fruits[i]);
  }
}