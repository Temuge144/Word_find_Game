void main(){
  List numbers = [12, 7, 23, 9, 14];
  int max = numbers[0];
  for (int i = 0; i < numbers.length; i++){
   if (numbers[i] > max){
     max = numbers[i];
   }
  }
  print('The maxiumum element in the list in is $max');
}