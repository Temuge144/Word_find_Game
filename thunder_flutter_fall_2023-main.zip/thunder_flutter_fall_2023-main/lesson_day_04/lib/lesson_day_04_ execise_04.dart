void main(){
  for (int a = 1; a <= 20; a = a + 1){
    if (a % 5 == 0){
      print(a);
    }
  }
}