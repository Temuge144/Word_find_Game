void main(){
  int n = 0;
  for (int a = 1; a <= 10; a = a + 1){
    n = n - a;
  }
  print(n);
}