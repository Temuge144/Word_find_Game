void main(){
  int sum = 10;
  for (int i = 0; i <= 20; i = i + 1){
    if (i % 2 == 0){
      sum = sum + i;
    }
  }
  print(sum);
}