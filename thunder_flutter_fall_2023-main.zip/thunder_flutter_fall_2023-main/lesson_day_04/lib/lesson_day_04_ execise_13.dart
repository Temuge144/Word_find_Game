import 'dart:io';

void main(){
  print('give me a number');
  int n = 1;
  int num = int.parse(stdin.readLineSync()!);
  for (int i = 1; i <= num; i = i + 1){
    n = i * n;
  }
  print('Factorial of $num is $n');
}