void main(){
  List<int> numbers = [1, 2, 3, 4, 5];
  int n = 0;
  for (int i = 0; i < numbers.length; i++){
    n = n + numbers[i];
  }
  print('The sum of elements in the list is $n');
}