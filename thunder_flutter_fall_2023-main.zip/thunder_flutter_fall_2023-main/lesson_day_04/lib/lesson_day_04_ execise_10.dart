void main(){
  for (int i = 1; i <= 20; i = i + 1){
    if (i <= 10){
      print('$i this number is less yhen 10');
    } else {
      print('$i this number is bigger than 10');
    }
  }
}