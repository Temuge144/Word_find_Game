void main(){
  for (int a = 1; a <= 100; a = a + 1){
    if (a % 2 == 0){
      print(a);
    }
  }
}