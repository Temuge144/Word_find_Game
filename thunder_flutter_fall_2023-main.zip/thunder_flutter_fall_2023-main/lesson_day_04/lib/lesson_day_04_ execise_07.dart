void main(){
  for (int a = 10; a >= 0; a = a - 1){
    print(a);
  }
}