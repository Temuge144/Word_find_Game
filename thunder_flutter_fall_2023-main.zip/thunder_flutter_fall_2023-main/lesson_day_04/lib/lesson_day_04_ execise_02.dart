void main(){
  String name = 'Tsenguun';
  for (int a = 1; a <= 5; a = a + 1) {
    print('$a : $name');
  }
}