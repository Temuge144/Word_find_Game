void main(){
  for (int a = 1; a <= 10;a = a + 1){
    if (a % 2 == 1){
      print(a);
    }
  }
}