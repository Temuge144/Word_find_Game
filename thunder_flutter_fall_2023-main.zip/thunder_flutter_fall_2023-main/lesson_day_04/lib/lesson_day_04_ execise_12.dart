import 'dart:io';

void main(){
  print('give me  number');
  int num = int.parse(stdin.readLineSync()!);
  for (int i = 1; i <= num; i = i + 1){
    if (i % 2 == 0){
      print(i);
    }
  }
}