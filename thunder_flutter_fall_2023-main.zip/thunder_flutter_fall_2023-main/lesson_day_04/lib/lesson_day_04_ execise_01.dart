void main(){
  for (int a = 0; a <= 35; a = a + 1){
    print('$a : Hello');
  }
}