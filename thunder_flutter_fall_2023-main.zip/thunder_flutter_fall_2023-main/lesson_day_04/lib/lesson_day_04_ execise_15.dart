import 'dart:io';

void main(){
  print('give me a number');
  int z = 1;
  int num = int.parse(stdin.readLineSync()!);
  for (int i = 1; i <= num; i = i + 1){
    z = i * i;
    if (z % 2 == 0){
      print('Quadrat of $i is $z. This number is even');
    } else {
      print('Quadrat of $i is $z. This number is odd');
    }
  }
}