void main(){
  List numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
  List oddNumbers = [];
  for (int i = 0; i < numbers.length; i++){
    if (numbers[i] % 2 == 1){
      oddNumbers.add(numbers[i]);
    }
  }
  print('Odd numbers in the list: $oddNumbers');
}